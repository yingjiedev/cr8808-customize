'use strict';
'require view';
'require fs';
'require ui';

let localFile = '/etc/adblock/adblock.allowlist';
let notMsg, errMsg;

return view.extend({
	load: function () {
		return L.resolveDefault(fs.stat(localFile), "")
			.then(function (stat) {
			if (!stat) {
				return fs.write(localFile, "");
			}
			return Promise.all([
				L.resolveDefault(fs.stat(localFile), ""),
				L.resolveDefault(fs.read_direct(localFile), "")
			]);
		});
	},
	render: function (allowlist) {
		if (allowlist[0] && allowlist[0].size >= 100000) {
			document.body.scrollTop = document.documentElement.scrollTop = 0;
			ui.addNotification(null, E('p', _('The allowlist is too big, unable to save modifications.')), 'error');
		}
		return E('div', { 'class': 'cbi-section cbi-section-descr' }, [
			E('p', _('This is the local adblock allowlist to always-allow certain domains.<br /> \
				<em><b>Please note:</b></em> add only one domain per line. Comments introduced with \'#\' are allowed - ip addresses, wildcards and regex are not.')),
			E('textarea', {
				'style': 'width: 100% !important; padding: 5px; font-family: monospace; margin-top: .4em',
				'spellcheck': 'false',
				'wrap': 'off',
				'rows': 25
			}, [allowlist[1] != null ? allowlist[1] : ''])
		]);
	},
	handleSave: function (ev) {
		let value = ((document.querySelector('textarea').value || '').trim().toLowerCase().replace(/\r\n/g, '\n')) + '\n';
		return fs.write(localFile, value)
			.then(function () {
				document.querySelector('textarea').value = value;
				document.body.scrollTop = document.documentElement.scrollTop = 0;
				if (!notMsg) {
					ui.addNotification(null, E('p', _('Allowlist modifications have been saved, reload adblock that changes take effect.')), 'info');
					notMsg = true;
				}
			}).catch(function (e) {
				document.body.scrollTop = document.documentElement.scrollTop = 0;
				if (!errMsg) {
					ui.addNotification(null, E('p', _('Unable to save modifications: %s').format(e.message)), 'error');
					errMsg = true;
				}
			});
	},
	handleSaveApply: null,
	handleReset: null
});
