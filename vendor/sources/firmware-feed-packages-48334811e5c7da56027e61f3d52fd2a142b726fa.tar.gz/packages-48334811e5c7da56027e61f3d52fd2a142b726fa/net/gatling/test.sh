#!/bin/sh

gatling -h
